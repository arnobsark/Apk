package com.buetprep.tracker

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { render(); handler.postDelayed(this, 30000) }
    }
    private val INK = 0xFF10243E.toInt()
    private val MUTE = 0xFF5B6B7F.toInt()

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Alarms.channel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFFEAF0F5.toInt())
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(40), dp(16), dp(32))
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() { super.onResume(); Alarms.scheduleNext(this); handler.post(ticker) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    private fun tv(t: String, size: Float, bold: Boolean, color: Int): TextView {
        val v = TextView(this)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, android.graphics.Typeface.BOLD)
        return v
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(14), dp(14), dp(14), dp(14))
        val g = GradientDrawable()
        g.setColor(Color.WHITE); g.cornerRadius = dp(14).toFloat(); g.setStroke(dp(1), 0xFFD2DCE6.toInt())
        l.background = g
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(10), 0, 0)
        l.layoutParams = lp
        return l
    }

    private fun btn(t: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t; b.isAllCaps = false
        b.setOnClickListener { f() }
        b.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        return b
    }

    private fun render() {
        root.removeAllViews()
        val now = Calendar.getInstance()
        val m = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val date = Schedule.dateStr(now)
        val bl = Schedule.day(Schedule.dow(now))

        root.addView(tv("BUET Prep Tracker", 24f, true, INK))
        root.addView(tv(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now.time), 14f, false, MUTE))

        // Now card
        val hero = card()
        val ci = bl.indexOfFirst { it.s <= m && m < it.e }
        if (m < 390) {
            hero.addView(tv("Sleep", 28f, true, INK))
            hero.addView(tv("Wake up at 6:30 AM", 14f, false, MUTE))
        } else if (ci >= 0) {
            val cur = bl[ci]
            val left = cur.e - m
            hero.addView(tv("Now, until " + Schedule.fmt(cur.e), 13f, false, MUTE))
            hero.addView(tv(cur.title, 20f, true, INK))
            hero.addView(tv(if (left >= 60) (left / 60).toString() + " hr " + (left % 60) + " min left" else "$left min left", 30f, true, INK))
            if (ci + 1 < bl.size) hero.addView(tv("Next: " + bl[ci + 1].title + " at " + Schedule.fmt(bl[ci + 1].s), 13f, false, MUTE))
        }
        root.addView(hero)

        // Stats
        val st = bl.withIndex().filter { it.value.cat == "study" }
        val dn = st.count { Store.done(this, date, it.index) }
        val stats = card()
        stats.addView(tv("$dn of ${st.size} study blocks done today", 16f, true, INK))
        stats.addView(tv("Streak: " + Schedule.streak(this) + " days (80% of study blocks keeps it)", 13f, false, MUTE))
        root.addView(stats)

        // Settings
        val set = card()
        val r1 = LinearLayout(this)
        r1.addView(btn("Test notification") {
            Alarms.show(this, Ev(0, "test", "t", 0, "Test notification", "Reminders will look like this."))
        })
        r1.addView(btn("Reminder: " + Store.lead(this) + " min") {
            Store.setLead(this, when (Store.lead(this)) { 5 -> 10; 10 -> 15; else -> 5 })
            Alarms.scheduleNext(this); render()
        })
        val r2 = LinearLayout(this)
        r2.addView(btn("Warnings: " + (if (Store.warn(this)) "on" else "off")) {
            Store.setWarn(this, !Store.warn(this)); render()
        })
        r2.addView(btn("Battery settings") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        set.addView(r1); set.addView(r2)
        root.addView(set)

        // Week progress
        val plan = DoubleArray(3); val done = DoubleArray(3)
        for (i in 0..6) {
            val d = now.clone() as Calendar
            d.add(Calendar.DAY_OF_YEAR, i - Schedule.dow(now))
            val ds = Schedule.dateStr(d)
            Schedule.day(i).forEachIndexed { j, b ->
                if (b.cat == "study") {
                    val h = (b.e - b.s) / 60.0
                    plan[b.subj] += h
                    if (Store.done(this, ds, j)) done[b.subj] += h
                }
            }
        }
        val wk = card()
        wk.addView(tv("This week", 16f, true, INK))
        for (k in 0..2) {
            wk.addView(tv(Schedule.SUB[k] + ": " + String.format(Locale.US, "%.1f", done[k]) + " of " + String.format(Locale.US, "%.1f", plan[k]) + " hrs", 13f, false, MUTE))
            val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
            pb.max = 100
            pb.progress = if (plan[k] > 0) (done[k] / plan[k] * 100).toInt() else 0
            wk.addView(pb)
        }
        root.addView(wk)

        // Today's plan
        root.addView(tv("Today's plan", 18f, true, INK).also { it.setPadding(0, dp(18), 0, dp(4)) })
        bl.forEachIndexed { i, b ->
            if (b.tracked) {
                val cb = CheckBox(this)
                cb.text = Schedule.fmt(b.s) + "   " + b.title
                cb.textSize = 15f
                cb.isChecked = Store.done(this, date, i)
                cb.setOnCheckedChangeListener { _, v -> Store.setDone(this, date, i, v); render() }
                root.addView(cb)
            } else {
                val t = tv(Schedule.fmt(b.s) + "   " + b.title, 14f, false, MUTE)
                t.setPadding(dp(8), dp(8), 0, dp(8))
                root.addView(t)
            }
        }
    }
}

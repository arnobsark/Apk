package com.buetprep.tracker

import android.content.Context
import java.util.Calendar
import java.util.Locale

data class Block(val s: Int, val e: Int, val title: String, val cat: String, val subj: Int) {
    val tracked: Boolean get() = cat == "study" || cat == "class" || cat == "hw" || cat == "review"
}

object Schedule {
    val SUB = listOf("Math", "Physics", "Chemistry")
    val PLAN = listOf(12.0, 10.0, 8.0)
    // Sunday..Saturday: subject index for block 1, 2, 3
    private val ROT = listOf(
        listOf(0, 1, 0), listOf(1, 0, 2), listOf(2, 1, 0), listOf(0, 1, 2),
        listOf(1, 2, 0), listOf(0, 1, 2), listOf(0, 1, 2)
    )

    private fun tm(h: String): Int { val p = h.split(":"); return p[0].toInt() * 60 + p[1].toInt() }
    private fun b(s: String, e: String, title: String, c: String, j: Int = -1) = Block(tm(s), tm(e), title, c, j)

    /** dow: 0 = Sunday ... 6 = Saturday. Sun-Thu are college days. */
    fun day(dow: Int): List<Block> {
        val r = ROT[dow]
        val S = SUB
        return if (dow < 5) listOf(
            b("6:30", "7:00", "Wake up, prayer, freshen up", "rest"),
            b("7:00", "9:00", S[r[0]] + " (hardest topic)", "study", r[0]),
            b("9:00", "9:15", "Break", "rest"),
            b("9:15", "10:15", S[r[1]], "study", r[1]),
            b("10:15", "10:30", "Get ready", "rest"),
            b("10:30", "17:00", "Travel and college", "college"),
            b("17:00", "18:00", "Bath, snack, rest, prayer", "rest"),
            b("18:00", "20:00", "College homework", "hw"),
            b("20:00", "20:30", "Dinner", "rest"),
            b("20:30", "22:00", "Online class", "class"),
            b("22:00", "23:00", S[r[2]] + " + error log", "study", r[2]),
            b("23:00", "24:00", "Sleep", "sleep")
        ) else listOf(
            b("6:30", "7:00", "Wake up, prayer, breakfast", "rest"),
            b("7:00", "9:00", S[r[0]], "study", r[0]),
            b("9:00", "9:30", "Break", "rest"),
            b("9:30", "11:00", S[r[1]], "study", r[1]),
            b("11:00", "12:00", "Online class", "class"),
            b("12:00", "14:00", "Lunch, prayer, rest", "rest"),
            b("14:00", "16:00", "College homework", "hw"),
            b("16:00", "16:30", "Break", "rest"),
            b("16:30", "18:00", S[r[2]], "study", r[2]),
            b("18:00", "19:00", "Dinner and rest", "rest"),
            b("19:00", "20:15", "Online class", "class"),
            b("20:15", "20:45", "Weekly error review", "review"),
            b("20:45", "22:30", "Free time", "free"),
            b("22:30", "24:00", "Sleep", "sleep")
        )
    }

    fun dateStr(c: Calendar): String = String.format(
        Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)
    )
    fun dow(c: Calendar) = c.get(Calendar.DAY_OF_WEEK) - 1
    fun midnight(c: Calendar): Calendar {
        val x = c.clone() as Calendar
        x.set(Calendar.HOUR_OF_DAY, 0); x.set(Calendar.MINUTE, 0); x.set(Calendar.SECOND, 0); x.set(Calendar.MILLISECOND, 0)
        return x
    }
    fun fmt(m: Int): String {
        val mm = m % 1440
        var h = mm / 60
        val n = mm % 60
        val ap = if (h >= 12) "PM" else "AM"
        h %= 12
        if (h == 0) h = 12
        return "$h:" + String.format(Locale.US, "%02d", n) + " $ap"
    }

    fun pct(c: Context, cal: Calendar): Double {
        val d = dateStr(cal)
        val st = day(dow(cal)).withIndex().filter { it.value.cat == "study" }
        return st.count { Store.done(c, d, it.index) }.toDouble() / st.size
    }
    fun streak(c: Context): Int {
        val cal = Calendar.getInstance()
        if (pct(c, cal) < 0.8) cal.add(Calendar.DAY_OF_YEAR, -1)
        var n = 0
        while (pct(c, cal) >= 0.8 && n < 400) { n++; cal.add(Calendar.DAY_OF_YEAR, -1) }
        return n
    }
}

object Store {
    private fun p(c: Context) = c.getSharedPreferences("bp", Context.MODE_PRIVATE)
    fun done(c: Context, date: String, i: Int) = p(c).getBoolean("d:$date:$i", false)
    fun setDone(c: Context, date: String, i: Int, v: Boolean) = p(c).edit().putBoolean("d:$date:$i", v).apply()
    fun warn(c: Context) = p(c).getBoolean("warn", true)
    fun setWarn(c: Context, v: Boolean) = p(c).edit().putBoolean("warn", v).apply()
    fun lead(c: Context) = p(c).getInt("lead", 5)
    fun setLead(c: Context, v: Int) = p(c).edit().putInt("lead", v).apply()
    fun last(c: Context) = p(c).getLong("last", 0L)
    fun setLast(c: Context, v: Long) = p(c).edit().putLong("last", v).apply()
}

package com.buetprep.tracker

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

const val CH = "routine"
const val ACTION_DONE = "com.buetprep.tracker.DONE"

data class Ev(val at: Long, val kind: String, val date: String, val idx: Int, val title: String, val text: String)

object Alarms {
    fun channel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CH, "Routine reminders", NotificationManager.IMPORTANCE_HIGH)
            ch.enableVibration(true)
            c.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    fun events(c: Context): List<Ev> {
        val out = ArrayList<Ev>()
        val lead = Store.lead(c)
        val now = Calendar.getInstance()
        for (off in -1..7) {
            val d = Schedule.midnight(now)
            d.add(Calendar.DAY_OF_YEAR, off)
            val base = d.timeInMillis
            val date = Schedule.dateStr(d)
            Schedule.day(Schedule.dow(d)).forEachIndexed { i, b ->
                fun at(m: Int) = base + m * 60000L
                if (b.cat == "sleep") {
                    out.add(Ev(at(b.s - 30), "sleep", date, i, "Sleep in 30 minutes", "Wrap up now. Sleep is when today's study sticks."))
                } else if (b.tracked) {
                    out.add(Ev(at(b.s - lead), "pre", date, i, b.title + " in " + lead + " min", "Get your things ready."))
                    out.add(Ev(at(b.s), "start", date, i, "Start now: " + b.title, "Until " + Schedule.fmt(b.e) + ". Phone away."))
                    if (b.e + 10 <= 1410) {
                        out.add(Ev(at(b.e + 10), "miss", date, i, "Not marked done: " + b.title, "Make it up tonight, or tick it off if you did it."))
                    }
                }
            }
        }
        return out.sortedBy { it.at }
    }

    fun scheduleNext(c: Context) {
        val now = System.currentTimeMillis()
        val floor = maxOf(now + 500, Store.last(c))
        val ev = events(c).firstOrNull { it.at > floor } ?: return
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            c, 1, Intent(c, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ev.at, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ev.at, pi)
        }
    }

    /** Called when the alarm rings: show everything due, then schedule the next one. */
    fun fire(c: Context) {
        val now = System.currentTimeMillis()
        val last = Store.last(c)
        events(c).filter { it.at > last && it.at <= now + 1500 && it.at >= now - 10 * 60000L }.forEach { show(c, it) }
        Store.setLast(c, now + 1500)
        scheduleNext(c)
    }

    fun show(c: Context, e: Ev) {
        if ((e.kind == "miss" || e.kind == "sleep") && !Store.warn(c)) return
        if (e.kind == "miss" && Store.done(c, e.date, e.idx)) return
        val nid = (e.date + e.kind + e.idx).hashCode()
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CH)
        else Notification.Builder(c).setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(e.title).setContentText(e.text)
            .setContentIntent(open).setAutoCancel(true)
        if (e.kind == "miss") {
            val di = Intent(c, AlarmReceiver::class.java).setAction(ACTION_DONE)
                .putExtra("date", e.date).putExtra("idx", e.idx).putExtra("nid", nid)
            val dp = PendingIntent.getBroadcast(c, nid, di, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            b.addAction(0, "Mark done", dp)
        }
        c.getSystemService(NotificationManager::class.java).notify(nid, b.build())
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == ACTION_DONE) {
            Store.setDone(c, i.getStringExtra("date") ?: return, i.getIntExtra("idx", 0), true)
            c.getSystemService(NotificationManager::class.java).cancel(i.getIntExtra("nid", 0))
            return
        }
        Alarms.fire(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Alarms.channel(c)
        Alarms.scheduleNext(c)
    }
}

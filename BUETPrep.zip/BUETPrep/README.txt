BUET Prep Tracker (native Android, Kotlin, no extra libraries)

BUILD THE APK
1. Install Android Studio (free). Open this folder (BUETPrep) with File > Open. Let it sync (needs internet once).
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Find it at app/build/outputs/apk/debug/app-debug.apk, copy to your phone and install (allow "install unknown apps").

AFTER INSTALLING
- Allow notifications when asked.
- Tap "Battery settings" and set the app to Unrestricted. On Xiaomi/Oppo/Realme/Vivo also enable Autostart and lock the app in recents.
- Tap "Test notification" to check.

HOW ALERTS WORK
Android's alarm service wakes the app at each reminder time, even when the app is closed. Each time one rings, the app schedules the next one. Rebooting the phone re-arms them automatically.
